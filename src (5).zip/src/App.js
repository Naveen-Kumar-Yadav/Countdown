
import './App.css';

import Timer from './components/Timer';

function App() {
  return (
    <div className="App">
   <Timer />
      
    </div>
  );
}

export default App;
